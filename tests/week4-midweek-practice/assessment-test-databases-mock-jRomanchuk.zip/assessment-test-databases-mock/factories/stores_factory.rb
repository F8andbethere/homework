FactoryGirl.define do
  factory :store do
    name           "H&M Downtown"
    annual_revenue 1_000_000
  end
end
