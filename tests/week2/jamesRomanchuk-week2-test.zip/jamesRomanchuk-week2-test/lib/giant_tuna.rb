class GiantTuna < Fish

  def initialize
    super(2, 25)
    @value_per_kg = 12.5
  end
end