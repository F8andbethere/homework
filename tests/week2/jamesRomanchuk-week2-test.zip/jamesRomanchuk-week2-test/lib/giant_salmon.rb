class GiantSalmon < Fish

  def initialize
    super(4, 30)
    @value_per_kg = 7.5
  end
end