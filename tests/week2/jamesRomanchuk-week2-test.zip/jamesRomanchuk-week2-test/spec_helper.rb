require 'rspec'
require './safe_require'

safe_require 'fish'
safe_require 'giant_tuna'
safe_require 'giant_salmon'
safe_require 'ocean'
safe_require 'submarine'

