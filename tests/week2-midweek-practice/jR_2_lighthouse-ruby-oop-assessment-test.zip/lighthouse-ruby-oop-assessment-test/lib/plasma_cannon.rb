class PlasmaCannon < Weapon

  def initialize
    @name = "Plasma Cannon"
    @weight = 200
    @damage = 55
  end
end